package com.tubb.cityindex;

public interface Indexer {
    int getStartPositionOfSection(String section);
}
